# Validation

Package version: 0.1.0 (experimental).

On 2026-09-11, 19 fixture tests passed on macOS with Node.js 26.8.2. The Node 24/26
and Linux/macOS/Windows CI matrix is separate coverage and must be checked on GitHub.

The automated suite exercises observable transport and configuration behavior:

- Namespace aliases, collisions, historical calls and exact freeform tool input.
- Desktop notifications without a call id, with their tool trust level preserved.
- NInfer option translation and preservation of explicit reasoning effort.
- End-to-end loopback HTTP/SSE with local credential isolation and account/API routing.
- Rejection of unknown models, stale removed-local entries, local compaction and browser origins.
- Terminal failures for upstream errors and incomplete streams.
- UTF-8 fragmentation, CRLF, multiline events, gzip and zstd requests.
- Client cancellation closing the upstream connection.
- Catalog construction and configure/restore preserving unrelated user edits.

Live compatibility results are recorded separately from fixture tests. Successful
prototype use does not establish every platform, desktop build, model or long-task
combination for this refactored package.

The refactored package was also exercised with Codex 0.153.4, overriding configuration
only for isolated ephemeral client processes:

| Backend | Result |
|---|---|
| NInfer / Qwen 3.8 | Completed; returned the requested `BRIDGE_OK` marker |
| oMLX / Qwen 3.6 | Completed; returned the requested `OMLX_BRIDGE_OK` marker |
| OpenAI account model | Completed; returned the requested `CLOUD_BRIDGE_OK` marker |

The existing desktop installation was not reconfigured for those tests. The new
package's GUI workflow and long conversations still need separate acceptance.
